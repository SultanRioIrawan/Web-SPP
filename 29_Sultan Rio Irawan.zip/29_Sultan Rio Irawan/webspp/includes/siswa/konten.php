<?php 

if (empty($_GET)) {
    include 'includes/transaksi.php';
} 

if (isset($_GET['p'])) {
    if ($_GET['p'] == 'transaksi') {
        require 'includes/transaksi.php';
    } elseif ($_GET['p'] == 'home') {
        require 'includes/transaksi.php';
    } elseif ($_GET['p'] == 'logout') {
        echo "<script>window.location.href='../../';</script>";
        session_destroy();
    } else {
        require '404.php';
    }
} elseif (isset($_GET['nis'])) {
    require 'includes/transaksi.php';
    $_SESSION['nis'] = $_GET['nis'];
} 

include 'footer.php';
?>