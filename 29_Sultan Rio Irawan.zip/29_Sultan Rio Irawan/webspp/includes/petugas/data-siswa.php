<div class="d-flex">
                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                    <p class="text-muted mb-0 hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;Home</p>
                    <p class="text-primary mb-0 hover-cursor"></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                <h1 class="card-title">Data Siswa</h1>
                <hr>
<br>
<table class="table">
    <tr>
        <th>No</th>
        <th>NISN</th>
        <th>NIS</th>
        <th>Nama Lengkap</th>
        <th>Kelas</th>
        <th>Jurusan</th>
        <th>tahun</th>
    </tr>
    <tr>
        <?php 
        $no = 1;
        $sws = $petugas->getDataSiswa();
           while($row = mysqli_fetch_assoc($sws)) :
        ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $row['nisn']; ?></td>
                <td><?= $row['nis']; ?></td>
                <td><?= $row['nama_lengkap']; ?></td>
                <td><?= $row['kelas']; ?></td>
                <td><?= $row['jurusan']; ?></td>
                <td><?= $row['tahun']?></td>
            </tr>
        <?php endwhile; ?>
    </tr>
</table>