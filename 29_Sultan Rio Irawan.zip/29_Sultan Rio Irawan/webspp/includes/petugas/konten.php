<?php 

if (empty($_GET)) {
    include 'home.php';
} 

if (isset($_GET['p'])) {
    if ($_GET['p'] == 'transaksi') {
        require 'includes/transaksi.php';
    } elseif ($_GET['p'] == 'home') {
        require 'home.php';
    } elseif ($_GET['p'] == 'siswa') {
        require 'data-siswa.php';
    } elseif ($_GET['p'] == 'logout') {
        echo "<script>window.location.href='../../';</script>";
        session_destroy();
    } else {
        require '404.php';
    }
} elseif (isset($_GET['nis'])) {
    require 'includes/transaksi.php';
    $_SESSION['nis'] = $_GET['nis'];
} 

include 'footer.php';
?>