<?php 
if (isset($_POST['submit'])) {
	$nama = $_POST['nama'];
	$username = $_POST['username'];
	$password = sha1($_POST['password']);
	$level = $_POST['level'];
	$id = $_GET['id'];

	if ($admin->ubahDataPetugas($nama, $username, $password, $level, $id)) {
        $_SESSION['pesan'] = '<script>
            swal({
                        title: "Sukses!",
                        text: "Data Petugas berhasil diubah!",
                        icon: "success",
                        button: "Ok"
                     })
            </script>';
		echo "<script>window.location.href='?p=petugas'</script>";
	} else {
		echo "<script>window.location.href='?p=petugas'</script>";
		$_SESSION['pesan'] = '<script>
            swal({
                        title: "Gagal!",
                        text: "Data Petugas gagal diubah!",
                        icon: "error",
                        button: "Ok"
                     })
            </script>';
	}
}
$data = $admin->getDataPetugas($_GET['id']);

foreach ($data as $row ) :

?>
<div class="d-flex">
                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                    <p class="text-muted mb-0 hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;Ubah Data Petugas</p>
                    <p class="text-primary mb-0 hover-cursor"></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
					<h2 class="card-title">Ubah Data Petugas</h2>
						<hr>
<form method="post">
	<label>Nama Lengkap</label><br>
	<input class="form-control" type="text" name="nama" required value="<?= $row['nama_petugas'];?>"><br>
	<label>Username</label><br>
	<input class="form-control" type="text" name="username" required value="<?= $row['username'];?>"><br>
	<label>Password</label><br>  
	<input class="form-control" type="password" name="password" required value="<?= $row['password'];?>"><br>
	<select class="form-control" name="level"><br>
		<option value="Admin">Admin</option>
		<option value="Petugas">Petugas</option>
    <option value="Siswa">Siswa</option>
	</select><br>
	<button class="btn btn-primary" type="submit" name="submit">Ubah</button>
	<a class="btn btn-danger" href="?p=petugas">Batal</a>
</form>

<?php 
endforeach;

 ?>