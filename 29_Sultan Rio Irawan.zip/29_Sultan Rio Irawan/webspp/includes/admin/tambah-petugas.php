<?php 

if (isset($_POST['submit'])) {
	$nama = htmlspecialchars($_POST['nama']);
	$username = htmlspecialchars($_POST['username']);
	$password = sha1($_POST['password']);
	$level = htmlspecialchars($_POST['level']);

	
	if ($admin->tambahDataPetugas($nama,$username,$password,$level)) {
        $_SESSION['pesan'] = '<script>
            swal({
                        title: "Sukses!",
                        text: "Data Petugas berhasil ditambahkan!",
                        icon: "success",
                        button: "Ok"
                     })
            </script>';
		echo "<script>window.location.href='?p=petugas'</script>";
	} else {
		echo "<script>window.location.href='?p=petugas'</script>";
		$_SESSION['pesan'] = '<script>
            swal({
                        title: "Gagal!",
                        text: "Data Petugas gagal ditambahkan!",
                        icon: "error",
                        button: "Ok"
                     })
            </script>';
	}
}

 ?>
 <div class="d-flex">
                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                    <p class="text-muted mb-0 hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;Tambah Petugas</p>
                    <p class="text-primary mb-0 hover-cursor"></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
					<h2 class="card-title">Tambah Petugas</h2>
						<hr>
<form method="post">
	<label>Nama Lengkap</label><br>
	<input class="form-control" type="text" name="nama"><br>
	<label>Username</label><br>
	<input class="form-control" type="text" name="username"><br>
	<label>Password</label><br>
	<input class="form-control" type="text" name="password"><br>
	<select class="form-control" name="level"><br>
		<option value="Admin">Admin</option>
		<option value="Petugas">Petugas</option>
    <option value="Siswa">Siswa</option>
	</select><br>
	<button class="btn btn-primary" type="submit" name="submit">Simpan</button>
	<a class="btn btn-danger" href="?p=petugas">Batal</a>
</form>