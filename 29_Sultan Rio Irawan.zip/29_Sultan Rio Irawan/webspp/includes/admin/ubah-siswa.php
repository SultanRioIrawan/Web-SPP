<?php 


if (isset($_POST['submit'])) {
    if($admin->ubahDataSiswa($_GET['id'],$_POST['nis'], $_POST['nama'], $_POST['kelas'],$_POST['jurusan'], $_POST['id_spp'], $_POST['nisn'])) 
    {
        echo "<script>window.location.href='?p=siswa'</script>";
        $_SESSION['pesan'] = '<script>
            swal({
                        title: "Sukses!",
                        text: "Data Siswa berhasil diubah!",
                        icon: "success",
                        button: "Ok"
                     })
            </script>';
    } else {
        echo "<script>window.location.href='?p=siswa'</script>";
        $_SESSION['pesan'] = '<script>
            swal({
                        title: "Gagal!",
                        text: "Data Siswa gagal diubah!",
                        icon: "error",
                        button: "Ok"
                     })
            </script>';
    }
}


if (isset($_GET['id'])) {
    $siswa = $admin->getDataSiswaById($_GET['id']);

    foreach ($siswa as $row) :
   
 ?>
 <div class="d-flex">
                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                    <p class="text-muted mb-0 hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;Ubah Data Siswa</p>
                    <p class="text-primary mb-0 hover-cursor"></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <h2 class="card-title">Ubah Data Siswa</h2>
                    <hr>
<form method="post">
    <input type="hidden" class="form-control" name="nisn" id="nisn" placeholder="nisn" value="<?= $row['nisn']; ?>" required><br>
<label for="nis">NIS :</label><br>
    <input type="text" class="form-control" name="nis" id="nis" placeholder="nis"value="<?= $row['nis']; ?>" required><br>
<label for="nama">Nama Lengkap :</label><br>
    <input type="text" class="form-control" name="nama" id="nama" placeholder="nama" value="<?= $row['nama_lengkap']; ?>" required><br>
<label for="kelas">Kelas :</label>
<select class="form-control" name="kelas" id="kelas">br
    <option value="1">X</option>
    <option value="2">XI</option>
    <option value="2">XII</option>
</select>
<label for="jurusan">Jurusan :</label><br>
    <select class="form-control" name="jurusan" id="jurusan"><br>
        <option value="RPL">RPL</option>
        <option value="TKJ">TKJ</option>
        <option value="OTP">OTP</option>
    </select><br>
<label for="tahun">Tahun Ajaran :</label>
<select class="form-control" name="id_spp" id="tahun"><br>
    <?php
    $spp = $admin->getDataSPP();
    foreach ($spp as $row) :
     ?>
     <option value="<?= $row['id_spp']; ?>"><?= $row['tahun'];?></option>
 <?php endforeach; ?>
</select><br>
    <input class="btn btn-primary" type="submit" name="submit" value="Simpan">
    <a class="btn btn-danger" href="?p=siswa">Batal</a>
</form>
<?php 
    endforeach;

}
 ?>