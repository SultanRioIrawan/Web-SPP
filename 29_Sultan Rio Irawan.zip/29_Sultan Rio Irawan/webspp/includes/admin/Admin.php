<?php

require_once '../../config/Koneksi.php';

$conn = mysqli_connect('localhost','root','','spp');

class Admin extends Koneksi {
 public function getDataPetugas($id) {
  $query = mysqli_query($this->konek, "SELECT * FROM tb_petugas WHERE id_petugas = '" . $id . "'");

  return $query;
 }

 public function getDataPembayaranPerPeriode($date1, $date2) {
    $query = mysqli_query($this->konek, "SELECT s.nisn,s.nama_lengkap,s.jurusan,s.kelas, p.tgl_bayar, spp.tahun, spp.nominal FROM tb_siswa AS s INNER JOIN tb_pembayaran AS p ON s.nisn = p.nisn INNER JOIN tb_spp AS spp ON p.id_spp = spp.id_spp WHERE p.tgl_bayar BETWEEN '$date1' and '$date2'");

    return $query;
}    

 public function getAllDataPetugas() {
  $query = mysqli_query($this->konek,"SELECT * FROM tb_petugas");

  return $query;
 }

 public function tambahDataPetugas($nama, $username, $password, $level) {
   $query = mysqli_query($this->konek,"INSERT INTO tb_petugas VALUES ('','$username','$password','$nama','$level')");

     if($query) {
        return true;
    } else {
        return false;
    }

 }

public function ubahDataPetugas($nama, $username, $password, $level, $id) {
   $query = mysqli_query($this->konek,"UPDATE tb_petugas SET nama_petugas = '$nama', username = '$username', password = '$password', level = '$level' WHERE id_petugas = '$id'");

   if ($query) {
     return true;
   } else {
     return false;
   }
}

 public function hapusDataPetugas($id) {
  $query = mysqli_query($this->konek,"DELETE FROM tb_petugas WHERE id_petugas = '$id'");


  if($query) {
        return true;
    } else {
        return false;
    }
 }

 public function getDataSPP() {
  $query = mysqli_query($this->konek, "SELECT * FROM tb_spp ORDER BY tahun ASC");

  return $query;
 }


 public function getDataSiswa() {
  $query = mysqli_query($this->konek, "SELECT * FROM tb_siswa INNER JOIN tb_spp ON tb_siswa.id_spp = tb_spp.id_spp ORDER BY nisn ASC");

  return $query;
 }


  public function getDataSPPbyId($id) {
    
      $query = mysqli_query($this->konek, "SELECT * FROM tb_spp WHERE id_spp ='".$id."'");
    
      return $query;
     }
 
  public function getDataSiswaById($id_siswa) {
    
      $query = mysqli_query($this->konek, "SELECT * FROM tb_siswa WHERE id_siswa ='$id_siswa'");
    
      return $query;
     }

 public function tambahDataSPP($tahun, $nominal) {
  $query = mysqli_query($this->konek,"INSERT INTO tb_spp VALUES ('', '" . $tahun . "', '" . $nominal . "')");

    if($query) {
        return true;
    } else {
        return false;
    }


 }
  
  public function tambahDataBayar($nisn, $bulan, $id_spp) {
  $query = mysqli_query($this->konek,"INSERT INTO tb_pembayaran (nisn,bulan_dibayar,id_spp,keterangan) VALUES ('$nisn','$bulan','$id_spp','Belum lunas')");

  if($query) {
        return true;
    } else {
        return false;
    }
}


  public function tambahDataSws($nisn, $nis, $nama, $kelas,$jurusan, $tahun) {
  $query = mysqli_query($this->konek,"INSERT INTO tb_siswa VALUES ('','$nisn','$nis','$nama','$kelas','$jurusan','$tahun')");

    if($query) {
        return true;
    } else {
        return false;
    }


 }
 
 
 public function ubahDataSPP($tahun, $nominal,$id) {
    $query = mysqli_query($this->konek, "UPDATE tb_spp SET tahun = '".$tahun."', nominal = '".$nominal."' WHERE id_spp = ".$id);

    if($query) {
        return true;
    } else {
        return false;
    }
 }

 public function ubahDataSiswa($id_siswa, $nis, $nama, $kelas,$jurusan, $tahun, $nisn) {
   $query =mysqli_query($this->konek,"UPDATE tb_siswa AS s, tb_pembayaran AS p SET s.nis = '$nis',s.nama_lengkap = '$nama',s.kelas = '$kelas',s.jurusan = '$jurusan', s.id_spp = '$tahun',p.id_spp = '$tahun' WHERE s.id_siswa = '$id_siswa'");

   if ($query) {
     return true;
   } else {
     return false;
   }
}

 public function hapusDataSPP($id) {
  $query = mysqli_query($this->konek,"DELETE FROM tb_spp WHERE id_spp =".$id);


  if($query) {
        return true;
    } else {
        return false;
    }
 }

 public function cekDataSiswa($nisn, $nis) {
   $query = mysqli_num_rows(mysqli_query($this->konek,"SELECT * FROM tb_siswa WHERE nisn ='$nisn' OR nis = '$nis'"));

    if($query) {
        return true;
    } else {
        return false;
    }
 }

public function hapusDataSiswa($nisn) {
  $query = mysqli_query($this->konek,"DELETE FROM tb_siswa WHERE nisn = '$nisn'");

  if($query) {
        return true;
    } else {
        return false;
    }
}

public function hapusDataBayar($nisn) {
  $query = mysqli_query($this->konek,"DELETE FROM tb_pembayaran WHERE nisn = '$nisn'");

  if($query) {
        return true;
    } else {
        return false;
    }
}
public function jumlahSiswa() {
    $query = mysqli_query($this->konek, "SELECT COUNT(*) AS jmlSiswa FROM tb_siswa");
  
    return $query;
   }

public function jumlahSPP() {
    $query = mysqli_query($this->konek, "SELECT COUNT(*) AS jmlSPP FROM tb_spp");
  
    return $query;
   }
public function jumlahPetugas() {
    $query = mysqli_query($this->konek, "SELECT COUNT(*) AS jmlPetugas FROM tb_petugas");
  
    return $query;
   }

   public function coba() {
    $query = mysqli_query($this->konek, "SELECT MAX(id_siswa) FROM tb_siswa");
  
    return $query;
   }


}