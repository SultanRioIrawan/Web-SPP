<div class="d-flex">
                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                    <p class="text-muted mb-0 hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;Data SPP</p>
                    <p class="text-primary mb-0 hover-cursor"></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                        <h2 class="card-title">Data SPP</h2>
                        <hr>
<a class="btn btn-primary mb-3" href="?p=tambah-spp"><i class="mdi mdi-plus"></i> Tambah data SPP</a>
<br>
<?php 
    if (isset($_SESSION['pesan'])) {
        echo $_SESSION['pesan'];
        unset($_SESSION['pesan']);
    }
?>
<table class="table">
    <tr>
        <th>No</th>
        <th>Tahun Ajaran</th>
        <th>Nominal</th>
        <th class="text-center">Aksi</th>
    </tr>
    <tr>
        <?php 
        $no = 1;
        $spp = $admin->getDataSPP();
            foreach($spp as $row) :
        ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $row['tahun']; ?></td>
                <td><?= $row['nominal']; ?></td>
                <td class="text-center"><a class="btn btn-primary mr-2" href="?p=ubah-spp&id=<?= $row['id_spp'];?>"><i class="mdi mdi-pencil-box-outline"></i> Edit</a><a class="btn btn-danger" href="?p=hapus-spp&id=<?= $row['id_spp'];?>" onclick="return confirm('data akan dihapus, yakin?')"><i class="mdi mdi-delete-forever"></i> Hapus</a></td>
            </tr>
        <?php endforeach; ?>
    </tr>
</table>