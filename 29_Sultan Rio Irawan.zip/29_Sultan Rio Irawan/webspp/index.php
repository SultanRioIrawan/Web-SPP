<?php
if(!session_id()) session_start();
require_once 'Proses.php';

$proses = new Proses;

if (isset($_SESSION['id'])) {
  if ($_SESSION['level'] == "Admin") {
    header('location:includes/admin');
  } else {
    header('location: petugas/');
  }
}

if(isset($_POST['masuk'])) {
  $username = $proses->konek->real_escape_string($_POST['username']);
  $password = $proses->konek->real_escape_string(sha1($_POST['password']));

  $masuk = $proses->loginPetugas($username, $password);
 if ($masuk->num_rows > 0 ) {
   $data = mysqli_fetch_assoc($masuk);
      if ($data['level'] == "Admin") {
        header('location:includes/admin/');
        $_SESSION['id'] = $data['id_petugas'];
        $_SESSION['level'] = $data['level'];
      } elseif($data['level'] == "Petugas") {
        header('location: includes/petugas/');
        $_SESSION['id'] = $data['id_petugas'];
        $_SESSION['level'] = $data['level'];
      } else {
        header('location: includes/siswa/');
        $_SESSION['id'] = $data['id_petugas'];
        $_SESSION['level'] = $data['level'];
      }
    } else {
      //echo "<script>alert('Login gagal');</script>";
      $_SESSION['error'] = '<div><script>
            swal({
                        title: "Gagal Login!",
                        text: "Username atau password tidak valid!",
                        icon: "warning",
                        button: "Ok"
                     })
            </script></div>';
    }
}
?>

<!doctype html>
<html>
<head>
 
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="icon" href="img/fav.png">
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/base/vendor.bundle.base.css">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
   <script src="assets/dist/jquery.min.js"></script>
   <script src="assets/dist/sweetalert.min.js"></script>
	<link rel="icon" type="icon" href="img/icon2.png">
	<title>Form Login</title>
<style type="text/css">
 body {
 	background: url(img/bg4.jpg);
  background-repeat: no-repeat;
 }	

.wrapper {
	margin: 80px;
}
.form-sign{
	max-width: 450px;
	margin: 0 auto;
	background-color: #fff;
	padding: 15px 40px 50px;
	border: 1px solid #e5e5e5;
	border-radius: 10px;
}

.form-sign .form-sign-heading, .form-signin, .checkbox {
	margin-bottom: 30px;
}
.form-signin input[type="text"], .form-signin input[type="password"] {
	margin-bottom: 30px;
}
</style>
</head>
<body>
<?php 
if(isset($_SESSION['error'])) {
  echo $_SESSION['error'];
  unset($_SESSION['error']);
}
?>

<div class="wrapper">
	
<form class="form-sign shadow md" method="post" action="">
	<h3 class="form-sign-heading text-center mt-3">Aplikasi Pembayaran SPP SMK YAJ DEPOK</h3>
	<input type="text" class="form-control mb-3" name="username" placeholder="Username" required="" autofocus=""/>
	<input type="password" class="form-control mb-3" name="password" placeholder="Password" required="">
    <label class="checkbox">
    	<input type="checkbox" value="remember-me" id="rememberMe" name="rememberMe"> Remember Me
    </label>
    <button type="submit" name="masuk" class="btn btn-lg btn-primary btn-block">Login</button>
</form>

</div>


<script src="vendors/base/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="vendors/js/off-canvas.js"></script>
  <script src="vendors/js/hoverable-collapse.js"></script>
  <script src="vendors/js/template.js"></script>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>
